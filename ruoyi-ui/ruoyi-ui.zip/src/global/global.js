// 接口地址
const apiUrl = "http://localhost:8083/yjData";

export default {
  apiUrl
};
